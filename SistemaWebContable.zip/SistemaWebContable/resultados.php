<?php
include("header.php");

// Crear una conexión a la base de datos usando MySQLi
$mysqli = new mysqli("localhost", "root", "", "contabilidad");

// Verificar la conexión
if ($mysqli->connect_error) {
    die("Error en la conexión a la base de datos: " . $mysqli->connect_error);
}

?>

<section class="contenido">
    <header class="tituloContenido">
        <hgroup>
            <h2>Empresa S.A.</h2>
            <h2>Estado de Resultados</h2>
            <h2>Julio 2012</h2>
        </hgroup>
    </header>
    <table class="tab">
        <?php

        // Consulta para obtener los ingresos (haber)
        $consultaIngresos = $mysqli->query("SELECT * FROM Ganancias_Y_Perdidas WHERE TIPO='haber'");
        $totalIngresos = 0;
        while ($row1 = $consultaIngresos->fetch_assoc()) {
            $totalIngresos += $row1['VALOR'];
        }

        // Consulta para obtener los gastos (debe)
        $consultaGastos = $mysqli->query("SELECT * FROM Ganancias_Y_Perdidas WHERE TIPO='debe'");
        $totalGastos = 0;
        while ($row2 = $consultaGastos->fetch_assoc()) {
            $totalGastos += $row2['VALOR'];
        }

        echo "<tr>
                <th>1. Total Ingresos</th>
                <td></td>
                <td></td>
                <td class='valor cierre'>$totalIngresos</td>
            </tr>";

        // Mostrar los detalles de los ingresos
        $consultaIngresos = $mysqli->query("SELECT * FROM Ganancias_Y_Perdidas WHERE TIPO='haber'");
        while ($fila = $consultaIngresos->fetch_assoc()) {
            echo "<tr>
                    <td></td>
                    <td>{$fila['CUENTA']}</td>
                    <td class='valor'>{$fila['VALOR']}</td>
                    <td></td>
                </tr>";
        }

        echo "<tr>
                <th>2. Total Gastos</th>
                <td></td>
                <td></td>
                <td class='valor cierre'>$totalGastos</td>
            </tr>";

        // Mostrar los detalles de los gastos
        $consultaGastos = $mysqli->query("SELECT * FROM Ganancias_Y_Perdidas WHERE TIPO='debe'");
        while ($fila = $consultaGastos->fetch_assoc()) {
            echo "<tr>
                    <td></td>
                    <td>{$fila['CUENTA']}</td>
                    <td class='valor'>{$fila['VALOR']}</td>
                    <td></td>
                </tr>";
        }

        $utilidadAntesImpuestos = $totalIngresos - $totalGastos;

        echo "<tr>
                <th>3. Utilidad Antes de Impuestos</th>
                <td></td>
                <td></td>
                <td class='valor cierre'>$utilidadAntesImpuestos</td>
            </tr>";

        $impuesto = $utilidadAntesImpuestos * 0.33;

        echo "<tr>
                <th>4. Impuestos 33%</th>
                <td></td>
                <td></td>
                <td class='valor cierre'>$impuesto</td>
            </tr>";

        $utilidadNeta = $utilidadAntesImpuestos - $impuesto;
        echo "<tr>
                <th>5. Utilidad Neta</th>
                <td></td>
                <td></td>
                <td class='valor cierre'>$utilidadNeta</td>
            </tr>";
        ?>
    </table>
</section>

</body>
</html>
