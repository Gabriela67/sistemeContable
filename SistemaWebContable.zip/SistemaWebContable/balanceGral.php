<?php
include("header.php");

// Crear una conexión a la base de datos usando MySQLi
$mysqli = new mysqli("localhost", "root", "", "contabilidad");

// Verificar la conexión
if ($mysqli->connect_error) {
    die("Error en la conexión a la base de datos: " . $mysqli->connect_error);
}
?>

<section class="contenido">
    <header class="tituloContenido">
        <hgroup>
            <h2>Empresa S.A.</h2>
            <h2>Balance General</h2>
            <h2>Junio 2012</h2>
        </hgroup>
    </header>
    <table class='tab' id='tab'>
        <tr>
            <td rowspan='3'>
                <table class="tab2">
                    <tr>
                        <th colspan='2'>Activos</th>
                    </tr>
                    <?php
                    $consultaActivos = $mysqli->query("SELECT * FROM Resumen_Cuentas WHERE TIPO ='Activo'");
                    $consultaPasivos = $mysqli->query("SELECT * FROM Resumen_Cuentas WHERE TIPO ='Pasivo'");
                    $consultaPatrimonio = $mysqli->query("SELECT * FROM Resumen_Cuentas WHERE TIPO ='Patrimonio'");
                    $ConsultaTotalActivos = $mysqli->query("SELECT SUM(VALOR) AS TOTAL FROM Resumen_Cuentas WHERE TIPO='Activo'");
                    $ConsultaTotalPasivos = $mysqli->query("SELECT SUM(VALOR) AS TOTAL FROM Resumen_Cuentas WHERE TIPO='Pasivo'");
                    $ConsultaTotalPatrimonio = $mysqli->query("SELECT SUM(VALOR) AS TOTAL FROM Resumen_Cuentas WHERE TIPO='Patrimonio'");
                    $ConsultaTotalPatrimonio2 = $mysqli->query("SELECT VALOR FROM Utilidad_Del_Ejercicio");
                    $totalActivos = $ConsultaTotalActivos->fetch_assoc();
                    $totalPasivos = $ConsultaTotalPasivos->fetch_assoc();
                    $totalPatrimonio = $ConsultaTotalPatrimonio->fetch_assoc();
                    $totalPatrimonio2 = $ConsultaTotalPatrimonio2->fetch_assoc();

                    while ($row1 = $consultaActivos->fetch_assoc()) {
                        echo "<tr>
                            <td>{$row1['CUENTA']}</td>
                            <td class='valor'>{$row1['VALOR']}</td>
                        </tr>";
                    }

                    echo "<tr>
                            <th>Total Activos</th>
                            <td class='valor cierreTmp'>{$totalActivos['TOTAL']}</td>
                        </tr>";
                    ?>
                </table>
            </td>
            <td colspan='2'>
                <table class="tab2">
                    <tr>
                        <th colspan='2'>Pasivos</th>
                    </tr>
                    <?php
                    while ($row2 = $consultaPasivos->fetch_assoc()) {
                        echo "<tr>
                            <td>{$row2['CUENTA']}</td>
                            <td class='valor'>{$row2['VALOR']}</td>
                        </tr>";
                    }

                    echo "<tr>
                            <th>Total Pasivos</th>
                            <td class='valor'>{$totalPasivos['TOTAL']}</td>
                        </tr>";
                    ?>
                    <tr>
                        <th colspan='2'>Patrimonio</th>
                    </tr>
                    <?php
                    while ($row3 = $consultaPatrimonio->fetch_assoc()) {
                        echo "<tr>
                            <td>{$row3['CUENTA']}</td>
                            <td class='valor'>{$row3['VALOR']}</td>
                        </tr>";
                    }

                    echo "<tr>
                            <td>Utilidad Del Ejercicio</td>
                            <td class='valor'>{$totalPatrimonio2['VALOR']}</td>
                        </tr>";
                    $patrimonioTotal = $totalPatrimonio['TOTAL'] + $totalPatrimonio2['VALOR'];

                    echo "<tr>
                            <th>Total Patrimonio</th>
                            <td class='valor'>{$patrimonioTotal}</td>
                        </tr>";
                    $patrimonioMasPasivo = $patrimonioTotal + $totalPasivos['TOTAL'];

                    echo "<tr>
                            <th>Total Patrimonio + Pasivos</th>
                            <td class='valor cierreTmp'>{$patrimonioMasPasivo}</td>
                        </tr>";
                    ?>
                </table>
            </td>
        </tr>
    </table>
</section>

</body>
</html>
