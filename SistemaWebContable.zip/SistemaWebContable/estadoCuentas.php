<?php
include("header.php");
?>

<section class="contenido">
    <header class="tituloContenido">
        <h2>Estado de Cuenta</h2>
    </header>
    <section id="nuevaCuenta">
        <form method="POST" action="creaCuenta.php">
            <label class="cuentaTitulo"><h3>Escoge la Cuenta</h3></label>
            
            <?php
            $servername = "localhost";
            $username = "root"; // Reemplaza con tu nombre de usuario de MySQL
            $password = ""; // Reemplaza con tu contraseña de MySQL
            $database = "contabilidad"; // Reemplaza con el nombre de tu base de datos

            // Crear una conexión a la base de datos
            $conn = mysqli_connect($servername, $username, $password, $database);

            // Verificar la conexión
            if (!$conn) {
                die("Error de conexión: " . mysqli_connect_error());
            }

            // Realizar una consulta SQL para seleccionar los datos de la tabla "cuentas"
            $query = "SELECT DETALLE  FROM cuentas";
            $result = $conn->query($query);

            if ($result->num_rows > 0) {
                echo "<select name='cuenta' class='opcionCuenta' id='verCuenta'>";
                echo "<option value=''>Selecciona una cuenta</option>";

                while ($row = $result->fetch_assoc()) {
                    echo "<option value='" . $row['DETALLE'] . "'>" . $row['DETALLE'] . "</option>";
                }

                echo "</select>";
            } else {
                echo "No se encontraron cuentas en la base de datos.";
            }

            // Cerrar la conexión a la base de datos
            $conn->close();
            ?>
            
            <section id="mostrarCuenta"></section>
        </form>
    </section>
</section>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function () {
        $("#verCuenta").change(function () {
            var id = $("#verCuenta").val();
            $("#mostrarCuenta").load('cargarCuenta.php?id=' + id);
        });
    });
</script>

</body>
</html>
