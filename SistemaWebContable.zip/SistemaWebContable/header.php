<!DOCTYPE HTML>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Contabilidad</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
	<script type="text/javascript" src="js/jquery.min.js"></script>
</head>
<body>
	<header class="header">
		<hgroup>
			<h2 class="tituloSitio">Sistemas Contables</h2>
		
		</hgroup>
		
	</header>


	<div class="container-menu">
    <div class="cont-menu">
        <nav>
            <a href="creaCuenta.php">Crear Cuenta</a>
            <a href="cuentas.php">Cuentas Creadas</a>
            <a href="transaccion.php">Realizar Transacción</a>
            <a href="resultados.php">Estado de Resultados Pro-Forma</a>
            <a href="balanceGral.php">Balance General Pro-Forma</a>
        </nav>
    </div>
</div>
	

	