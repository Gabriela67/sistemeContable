<?php
if (isset($_GET['id'])) {
    $nombre = $_GET['id'];

    if ($nombre != '') {
        $servername = "localhost"; // Reemplaza con el nombre de host correcto
        $username = "root"; // Reemplaza con tu nombre de usuario de MySQL
        $password = ""; // Reemplaza con tu contraseña de MySQL
        $database = "contabilidad"; // Reemplaza con el nombre de tu base de datos

        // Establece una conexión a la base de datos usando MySQLi
        $mysqli = new mysqli($servername, $username, $password, $database);

        if ($mysqli->connect_error) {
            die("Error en la conexión a la base de datos: " . $mysqli->connect_error);
        }

        $nombre = $mysqli->real_escape_string($nombre); // Escapa la entrada del usuario

        $consulta = $mysqli->query("SELECT * FROM " . $nombre . " ORDER BY FECHA");

        if ($consulta) {
            echo "<table class='tab'>
                <tr>
                    <th colspan='5' class='tituloCuenta'>$nombre</th>
                </tr>
                <tr>
                    <th>FECHA</th>
                    <th>DEBE</th>
                    <th>HABER</th>
                    <th>TOTAL DEBE</th>
                    <th>TOTAL HABER</th>
                </tr>";

            $totalDebe = 0;
            $totalHaber = 0;

            while ($row = $consulta->fetch_assoc()) {
                $col1 = $row['FECHA'];
                $col2 = ($row['TIPO'] == 'debe') ? $row['VALOR'] : '';
                $col3 = ($row['TIPO'] == 'haber') ? $row['VALOR'] : '';

                if ($col1 == NULL) {
                    $col1 = '';
                }

                if ($col2 != '') {
                    $totalDebe += $row['VALOR'];
                }

                if ($col3 != '') {
                    $totalHaber += $row['VALOR'];
                }

                echo "<tr>
                        <td>$col1</td>
                        <td>$col2</td>
                        <td>$col3</td>
                        <td>$totalDebe</td>
                        <td>$totalHaber</td>
                    </tr>";
            }

            echo "</table>";
        } else {
            echo "No se encontró la tabla '$nombre'";
        }

        // Cierra la conexión a la base de datos al finalizar
        $mysqli->close();
    } else {
        echo "Falta el parámetro 'id'";
    }
}
?>

