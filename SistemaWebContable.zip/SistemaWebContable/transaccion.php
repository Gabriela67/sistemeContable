<?php
include("header.php");

$mysqli = new mysqli("localhost", "root", "", "contabilidad");

if ($mysqli->connect_error) {
    die("Error en la conexión a la base de datos: " . $mysqli->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $cuenta1 = $_POST["cuenta1"];
    $valor1 = $_POST["valor1"];
    $tipo1 = $_POST["tipo1"]; // Tipo de transacción (Debe o Haber)
    $fecha = $_POST["fecha"];

    // Insertar datos en la tabla de la cuenta seleccionada
    $query = "INSERT INTO $cuenta1 (FECHA, VALOR, TIPO) VALUES (?, ?, ?)";
    $stmt = $mysqli->prepare($query);

    if ($stmt) {
        $stmt->bind_param("sss", $fecha, $valor1, $tipo1);

        if ($stmt->execute()) {
            // La inserción en la tabla de la cuenta seleccionada fue exitosa
           

            // Insertar datos en la tabla Resumen_Cuentas
            $query2 = "INSERT INTO Resumen_Cuentas (CUENTA, VALOR, TIPO) VALUES (?, ?, ?)";
            $stmt2 = $mysqli->prepare($query2);

            if ($stmt2) {
                $stmt2->bind_param("ssd", $cuenta1, $valor1, $tipo1);

                if ($stmt2->execute()) {
                    // La inserción en la tabla Resumen_Cuentas fue exitosa
                   
                } else {
                    echo "Error al insertar en la tabla Resumen_Cuentas: " . $stmt2->error;
                }

            } else {
                echo "Error en la preparación de la consulta para Resumen_Cuentas: " . $mysqli->error;
            }

           
        } else {
            echo "Error al realizar la inserción en la base de datos: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Error en la preparación de la consulta: " . $mysqli->error;
    }
}
?>

<section class="contenido">
    <header class="tituloContenido">
        <h2>Nueva Transaccion</h2>
    </header>

    <section id="nuevaTransacion">
        <table class='tab table-xl table-striped'>
            <form action="transaccion.php" method="POST">
                <div class="fecha">
                    <label for "fecha">Fecha</label>
                    <input name="fecha" type="date" placeholder="aaaa-mm-dd" required>
                </div>
                <tr>
                    <th>CUENTA</th>
                    <th>VALOR</th>
                    <th>TIPO TRANSACCION</th>
                </tr>
                <tr>
                    <td>
                        <?php
                        // Realizar una consulta SQL para seleccionar los datos de la tabla "cuentas"
                        $query = "SELECT DETALLE FROM cuentas";
                        $result = $mysqli->query($query);

                        if ($result->num_rows > 0) {
                            echo "<select name='cuenta1' class='opcionCuenta form-select' id='verCuenta'>";
                            echo "<option value=''>Selecciona una cuenta</option>";

                            while ($row = $result->fetch_assoc()) {
                                echo "<option value='" . $row['DETALLE'] . "'>" . $row['DETALLE'] . "</option>";
                            }

                            echo "</select>";
                        } else {
                            echo "No se encontraron cuentas en la base de datos.";
                        }
                        ?>
                    </td>
                    <td><input name="valor1" type="number" required></td>
                    <td>
                        <select name='tipo1' class="form-select">
                            <option value="debe">Debe</option>
                            <option value="haber">Haber</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td colspan="3"><input type="submit" value="Hacer Transaccion"></td>
                </tr>
            </form>
        </table>
    </section>
</section>
</body>
</html>
